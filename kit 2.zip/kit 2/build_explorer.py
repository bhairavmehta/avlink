#!/usr/bin/env python3
"""
build_explorer.py — build the Taxonomy Review Feedback Explorer (one self-contained HTML file)

Inputs
  --index      the Taxonomy Review page (index.html, or a .docx that contains its source)
  --feedback   reviewer exports from the review page: responses/<username>.json
               (files and/or folders; .json, .txt or .docx that contains the JSON)
  --config     explorer_config.json  (labels, roles, theme tags, contested notes, keyword rules)
  --template   explorer_template.html

Output
  --out        taxonomy_feedback_explorer.html

Example
  python build_explorer.py --index index.html --feedback responses/ feedback/ --out explorer.html

Only the standard library is needed; python-docx is used only if you pass .docx files
(pip install python-docx).
"""
import argparse
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
MAX_COLORS = 8  # categorical palette slots in the template


# ---------------------------------------------------------------- reading inputs
def read_text(path: Path) -> str:
    """Return the text of a .json / .txt / .html file, or of a Word document's paragraphs."""
    if path.suffix.lower() == ".docx":
        try:
            import docx  # python-docx
        except ImportError:
            sys.exit(f"{path.name}: reading .docx needs python-docx (pip install python-docx)")
        text = "\n".join(p.text for p in docx.Document(str(path)).paragraphs)
    else:
        text = path.read_text(encoding="utf-8-sig")
    # Word and some editors swap in non-breaking spaces, which JSON does not accept as whitespace
    return text.replace(" ", " ").replace("​", "")


def load_json_lenient(text: str, name: str):
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    # Word "smart quotes" around keys/values
    fixed = text.replace("“", '"').replace("”", '"')
    try:
        return json.loads(fixed)
    except json.JSONDecodeError as e:
        sys.exit(f"{name}: not valid JSON ({e})")


def collect_feedback_files(paths):
    files = []
    for p in map(Path, paths):
        if p.is_dir():
            files += sorted(f for f in p.iterdir() if f.suffix.lower() in (".json", ".txt", ".docx"))
        elif p.exists():
            files.append(p)
        else:
            sys.exit(f"Not found: {p}")
    if not files:
        sys.exit("No feedback files found.")
    return files


def load_reviewers(files, include_synthetic=True):
    by_user = {}
    for f in files:
        d = load_json_lenient(read_text(f), f.name)
        rv = d.get("reviewer") or {}
        user, name = rv.get("username"), rv.get("name")
        if not user or not isinstance(d.get("items"), dict):
            print(f"  skip {f.name}: missing reviewer.username or items", file=sys.stderr)
            continue
        if d.get("synthetic") and not include_synthetic:
            continue
        d["reviewer"]["name"] = name or user
        d["items"] = {k: v for k, v in d["items"].items() if v.get("flagged", True)}
        d["flaggedCount"] = len(d["items"])
        old = by_user.get(user)
        if old and old.get("updatedAt", "") >= d.get("updatedAt", ""):
            print(f"  {f.name}: older duplicate of {user}, ignored", file=sys.stderr)
            continue
        by_user[user] = d
    return by_user


# ---------------------------------------------------------------- index.html → taxonomy
def extract_js_array(src: str, var: str) -> str:
    m = re.search(r"\bconst\s+" + var + r"\s*=\s*\[", src)
    if not m:
        sys.exit(f"index: could not find 'const {var} = [' in the page")
    i, depth, quote = m.end() - 1, 0, None
    start = i
    while i < len(src):
        c = src[i]
        if quote:
            if c == "\\":
                i += 1
            elif c == quote:
                quote = None
        elif c in "\"'`":
            quote = c
        elif c == "/" and src[i + 1:i + 2] == "/":
            i = src.find("\n", i)
            continue
        elif c in "[{":
            depth += 1
        elif c in "]}":
            depth -= 1
            if depth == 0:
                return src[start:i + 1]
        i += 1
    sys.exit(f"index: unbalanced brackets in {var}")


def js_literal_to_json(js: str):
    out, i, quote = [], 0, None
    while i < len(js):  # drop // and /* */ comments outside strings
        c = js[i]
        if quote:
            out.append(c)
            if c == "\\":
                out.append(js[i + 1]); i += 1
            elif c == quote:
                quote = None
        elif c in "\"'":
            quote = c; out.append(c)
        elif js.startswith("//", i):
            i = js.find("\n", i); i = len(js) if i < 0 else i; continue
        elif js.startswith("/*", i):
            i = js.find("*/", i) + 2; continue
        else:
            out.append(c)
        i += 1
    s = "".join(out)
    s = re.sub(r"'((?:[^'\\]|\\.)*)'", lambda m: json.dumps(m.group(1)), s)   # 'x' → "x"
    s = re.sub(r"([{,]\s*)([A-Za-z_$][\w$]*)\s*:", r'\1"\2":', s)            # key: → "key":
    s = re.sub(r",\s*([\]}])", r"\1", s)                                      # trailing commas
    return json.loads(s)


def lanes_from_index(index_path: Path, lane_map: dict):
    tax = js_literal_to_json(extract_js_array(read_text(index_path), "TAXONOMY"))
    lanes, demo, seen = [], {}, set()
    for top in tax:
        lid, label = top["id"], top["label"]
        if lid in lane_map:
            mapped = lane_map[lid]
            if mapped is None:
                continue
            lid, label = mapped.get("id", lid), mapped.get("label", label)
        if lid in seen:
            continue
        seen.add(lid)
        lanes.append([lid, label])
        if top.get("children"):
            demo[lid] = top
    return lanes, demo


# ---------------------------------------------------------------- themes
def auto_tag(comment: str, rules: dict, max_tags=2):
    c = comment.lower()
    hits = [theme for theme, words in rules.items()
            if not theme.startswith("_") and any(w in c for w in words)]
    return hits[:max_tags]


def build_tags(reviewers, cfg):
    tags = {u: dict(v) for u, v in (cfg.get("tags") or {}).items()}
    rules = cfg.get("theme_keywords") or {}
    themes = cfg["themes"]
    auto, untagged = 0, []
    for user, d in reviewers.items():
        mine = tags.setdefault(user, {})
        for nid, item in d["items"].items():
            if nid in mine:
                mine[nid] = [t for t in mine[nid] if t in themes]
                continue
            got = [t for t in auto_tag(item.get("comment", ""), rules) if t in themes]
            mine[nid] = got
            auto += 1
            if not got:
                untagged.append(f"{user} | {nid}")
    return tags, auto, untagged


# ---------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--index", required=True, type=Path)
    ap.add_argument("--feedback", required=True, nargs="+")
    ap.add_argument("--config", type=Path, default=HERE / "explorer_config.json")
    ap.add_argument("--template", type=Path, default=HERE / "explorer_template.html")
    ap.add_argument("--out", type=Path, default=Path("taxonomy_feedback_explorer.html"))
    ap.add_argument("--no-synthetic", action="store_true", help="leave out reviewer files marked \"synthetic\": true")
    a = ap.parse_args()

    cfg = json.loads(a.config.read_text(encoding="utf-8"))
    tpl = a.template.read_text(encoding="utf-8")

    reviewers = load_reviewers(collect_feedback_files(a.feedback), include_synthetic=not a.no_synthetic)
    if not reviewers:
        sys.exit("No usable reviewer files.")
    order = cfg.get("reviewer_order") or []
    keys = sorted(reviewers, key=lambda u: (order.index(u) if u in order else len(order),
                                            bool(reviewers[u].get("synthetic")), reviewers[u]["reviewer"]["name"]))
    if len(keys) > MAX_COLORS:
        print(f"  note: {len(keys)} reviewers; only the first {MAX_COLORS} get a distinct colour, the rest are grey",
              file=sys.stderr)
    data = [reviewers[k] for k in keys]

    lane_map = {k: v for k, v in (cfg.get("lane_map") or {}).items() if not k.startswith("_")}
    lanes, demo = lanes_from_index(a.index, lane_map)

    tags, n_auto, untagged = build_tags(reviewers, cfg)
    page_cfg = {
        "first_names_only": cfg.get("first_names_only", True),
        "roles": cfg.get("roles", {}),
        "themes": cfg["themes"],
        "tags": tags,
        "contested": {k: v for k, v in (cfg.get("contested") or {}).items() if not k.startswith("_")},
        "labels": cfg.get("labels", {}),
    }

    def js(obj):  # safe to drop inside <script>
        return json.dumps(obj, ensure_ascii=False).replace("</", "<\\/")

    out = (tpl.replace("/*__DATA__*/[]", js(data))
              .replace("/*__CONFIG__*/{}", js(page_cfg))
              .replace("/*__LANES__*/[]", js(lanes))
              .replace("/*__DEMO__*/{}", js(demo))
              .replace("/*__TITLE__*/", cfg.get("title", "Taxonomy Review — Feedback Explorer"))
              .replace("/*__SUBTITLE__*/", cfg.get("subtitle", "")))
    leftover = re.findall(r"/\*__\w+__\*/", out)
    if leftover:
        sys.exit(f"Template placeholders not filled: {leftover}")
    a.out.write_text(out, encoding="utf-8")

    flags = sum(len(d["items"]) for d in data)
    nodes = len({n for d in data for n in d["items"]})
    print(f"Wrote {a.out}  ({len(out)//1024} KB)")
    print(f"  reviewers: {len(data)} ({sum(1 for d in data if d.get('synthetic'))} synthetic) · flags: {flags} · nodes: {nodes}")
    print(f"  lanes from index: {len(lanes)} ({', '.join(demo) or 'none'} built out)")
    print(f"  comments themed by keyword rules: {n_auto}" + (f" · no theme matched: {len(untagged)}" if untagged else ""))
    for u in untagged:
        print(f"    - {u}   (add it under 'tags' in the config)")


if __name__ == "__main__":
    main()
