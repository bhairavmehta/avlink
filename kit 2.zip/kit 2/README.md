# Taxonomy Review — Feedback Explorer build kit

Turns the Taxonomy Review page (`index.html`) and the reviewer exports it saves
(`responses/<username>.json` on the `sme_feedback` / `team_feedback` branch) into one
self-contained HTML file. The output has no external libraries, so it can sit next to the
review page on GitLab Pages or be emailed and opened by double-clicking.

## Files

| File | What it is |
|---|---|
| `build_explorer.py` | The build script. Python 3.8+; standard library only (`python-docx` only if you feed it `.docx`). |
| `explorer_template.html` | The page: HTML, CSS and JS with placeholders the script fills. |
| `explorer_config.json` | Everything that was hand-written: labels, roles, themes, per-comment theme tags, "contested" notes, keyword rules, lane mapping. |
| `index.html` | The original Taxonomy Review page, as attached (taken out of the Word file). |
| `responses/` | The original reviewer exports: Cedar, Tak-Kei and Sahba, named `<username>.json` as the review page saves them. |
| `feedback/` | The 5 synthetic reviewers (Paden, Jeff, Amanda, Thad, Edmond), marked `"synthetic": true`. |

## Run it

From inside this folder, everything needed is already here:

```bash
python build_explorer.py --index index.html --feedback responses/ feedback/ --out explorer.html
```

Other variations:

```bash
# real + synthetic reviewers
python build_explorer.py --index index.html --feedback responses/ feedback/ --out explorer.html

# real reviewers only (the synthetic switch disappears from the page)
python build_explorer.py --index index.html --feedback responses/ feedback/ --no-synthetic --out explorer.html

# straight from the Word attachments (pip install python-docx)
python build_explorer.py --index index.html.docx --feedback takjson.docx sahbajson.docx cedarjson.docx feedback/
```

`--feedback` takes any mix of files and folders (`.json`, `.txt`, `.docx`). If a reviewer
appears twice, the file with the newer `updatedAt` wins. Unflagged items are ignored.

The script prints a summary and lists any comment it could not assign to a theme:

```
Wrote explorer.html  (78 KB)
  reviewers: 8 (5 synthetic) · flags: 70 · nodes: 31
  lanes from index: 23 (ri built out)
  comments themed by keyword rules: 0
```

## What comes from where

* **Lanes and the "Original index.html demo tree"**: read from the `TAXONOMY` array in
  `index.html`. `lane_map` in the config renames or drops lanes. By default it merges
  *RE — Landing* and *RE — Takeoff* into one `re` lane, because the feedback ids split RE by phase.
* **The reviewed tree**: rebuilt from the feedback node ids, `category.phase.occurrence.cause.item`
  (e.g. `ri.tko.2200101.pilot-flight-crew.r7`). Display names come from the item `label`s in
  the feedback and from `labels` in the config (category, phase, occurrence code, cause bucket).
  An occurrence code with no label shows as "Occurrence 2070100".
* **Themes**: `tags[username][node id]` in the config is the hand coding and always wins.
  Any comment without an entry is themed by `theme_keywords` (case-insensitive substring
  match, up to two themes). The script lists comments that match nothing so you can tag them.
* **Contested ⚡ and the "Discuss first" column**: `contested[node id]` in the config, one
  sentence describing the disagreement. These are written by hand, not detected.
* **Roles**: `roles[username]` for real reviewers. Synthetic files carry their own `role`.
* **Reviewer colours**: assigned in `reviewer_order`, then any others (real before synthetic).
  The palette has 8 colours; any reviewer after the 8th is grey.

## Adding a new round of feedback

1. Pull the latest `responses/*.json` from the feedback branch.
2. Re-run the build. New comments get themes from the keyword rules.
3. Optionally add hand tags or contested notes to `explorer_config.json` and re-run.
